package com.example.dsmobile;

import android.os.Bundle;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.dsmobile.databinding.ActivityMainBinding;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView saisir_nom_clien: (TextView) findViewById(R.id.saisir_nom_clien);
        TextView Référence: (TextView) findViewById(R.id.Référence);
        TextView Date: (TextView) findViewById(R.id.Date);
        TextView Date_fin: (TextView) findViewById(R.id.Date_fin);
        TextView Redevence: (TextView) findViewById(R.id.Redevence);
        TextView Client: (TextView) findViewById(R.id.Client);
        TextView add_Client: (TextView) findViewById(R.id.add_Client);
        MaterialButton bttnBack :(MaterialButton) findViewById(R.id.bttnBack);



    }
}

